# 📈 Stock Price Prediction using Sentiment Analysis & LSTM

This repository contains my final-year project on **predicting stock price movement based on financial news sentiment**.  
It combines **NLP (VADER Sentiment Analysis)** and **Deep Learning (LSTM)** to forecast stock price direction.

---

## 🚀 Project Overview
- Collected financial news data and stock prices using `yfinance`
- Preprocessed and cleaned textual + price data
- Performed sentiment analysis using **VADER**
- Built and trained an **LSTM model** for prediction
- Evaluated using accuracy and classification metrics

---

## 📂 Repository Structure
```
stock-price-prediction/
│── data/                  # Sample data (if shareable)
│── notebooks/             # Jupyter Notebooks
│   └── stock_sentiment_lstm.ipynb
│── reports/               # Final report and results
│   └── Stock_Prediction_Report.pdf
│── src/                   # Core python scripts
│   ├── data_preprocessing.py
│   ├── sentiment_analysis.py
│   ├── lstm_model.py
│   └── utils.py
│── requirements.txt       # List of dependencies
│── README.md              # This file
│── LICENSE                # License file
│── .gitignore             # Files ignored in git
```

---

## ⚙️ Installation
Clone the repo and install dependencies:
```bash
git clone https://github.com/YOUR-USERNAME/stock-price-prediction.git
cd stock-price-prediction
pip install -r requirements.txt
```

---

## 📊 Results
- **Model Accuracy:** ~XX% (replace with your result)
- Predictions aligned with news-driven stock movements
- Report available in [`reports/Stock_Prediction_Report.pdf`](reports/Stock_Prediction_Report.pdf)

---

## 🛠️ Tech Stack
- **Python** (NumPy, Pandas, Matplotlib, Seaborn)
- **NLP:** NLTK VADER
- **Finance API:** yfinance
- **Deep Learning:** TensorFlow / Keras (LSTM)

---

## 📄 License
This project is licensed under the [MIT License](LICENSE).

---

## 🤝 Contributing
Contributions, issues, and feature requests are welcome!  
Feel free to fork this repo and submit pull requests.

---

## 🙌 Acknowledgments
- Yahoo Finance API for stock data
- NLTK for sentiment analysis
- TensorFlow/Keras for deep learning
